package com.example.belajarview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Alamat extends AppCompatActivity {
Button BtnKirimkan;
TextView TvStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alamat);

        BtnKirimkan = findViewById(R.id.btn_kirimkan);
        TvStatus = findViewById(R.id.tv_status);
        BtnKirimkan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Alamat.this,Alamat.class);
                TvStatus.setText("Berhasil diproses");
                startActivity(a);
            }
        });
    }
}
